#!/bin/sh
cd /mnt/us/kindlesync
/mnt/us/kindlesync/python/bin/python2.6 sync_comments.py >> result.log
