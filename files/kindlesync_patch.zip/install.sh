#!/bin/sh
mntroot rw
cp /mnt/us/kindlesync/root /etc/crontab/root
mntroot ro
/etc/init.d/cron restart